@echo off
setlocal
title Weather Widget Setup
color 0B

echo ============================================
echo   Weather Widget - Setup
echo ============================================
echo.

set "APPDIR=%LOCALAPPDATA%\WeatherWidget"
set "SRCDIR=%~dp0"
set "BUILDTMP=%TEMP%\weatherwidget_build"

REM ---------------------------------------------------------------
REM 1. Find Python (try the py launcher first, then python)
REM ---------------------------------------------------------------
set "PYCMD="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3"

if not defined PYCMD (
    python --version >nul 2>&1
    if not errorlevel 1 set "PYCMD=python"
)

if not defined PYCMD (
    echo Python was not found on this computer.
    where winget >nul 2>&1
    if not errorlevel 1 (
        echo Trying to install Python automatically via winget...
        winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
        echo.
        echo Python setup finished. Please CLOSE this window and run
        echo install.bat again to continue installing the widget.
        pause
        exit /b 0
    ) else (
        echo Automatic install is not possible ^(winget not found^).
        echo Please install Python 3.10+ manually from:
        echo   https://www.python.org/downloads/windows/
        echo Make sure to check "Add python.exe to PATH" during setup.
        echo Then run install.bat again.
        pause
        exit /b 1
    )
)

echo Found Python: %PYCMD%
echo.

REM ---------------------------------------------------------------
REM 2. Install PyInstaller (only needed once, for building the exe)
REM ---------------------------------------------------------------
echo Preparing build tool...
%PYCMD% -m pip install --quiet --disable-pip-version-check pyinstaller
if errorlevel 1 (
    echo Could not install PyInstaller. Check your internet connection.
    pause
    exit /b 1
)

REM ---------------------------------------------------------------
REM 3. Build WeatherWidget.exe directly into the app folder
REM ---------------------------------------------------------------
echo Building the application...
if not exist "%APPDIR%" mkdir "%APPDIR%"

%PYCMD% -m PyInstaller --onefile --noconsole --clean ^
    --name WeatherWidget ^
    --distpath "%APPDIR%" ^
    --workpath "%BUILDTMP%" ^
    --specpath "%BUILDTMP%" ^
    "%SRCDIR%weather_widget.py"

if not exist "%APPDIR%\WeatherWidget.exe" (
    echo.
    echo Build failed - WeatherWidget.exe was not created.
    pause
    exit /b 1
)

REM Clean up temporary build files
rmdir /s /q "%BUILDTMP%" >nul 2>&1

echo.
echo Application built: %APPDIR%\WeatherWidget.exe
echo.

REM ---------------------------------------------------------------
REM 4. Shortcuts - Desktop and Start Menu
REM ---------------------------------------------------------------
echo Creating shortcuts...

set "DESKTOP=%USERPROFILE%\Desktop\Weather.lnk"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Weather.lnk"

powershell -NoProfile -Command ^
    "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%DESKTOP%'); " ^
    "$s.TargetPath = '%APPDIR%\WeatherWidget.exe'; " ^
    "$s.WorkingDirectory = '%APPDIR%'; " ^
    "$s.Description = 'Weather Widget'; " ^
    "$s.Save()"

powershell -NoProfile -Command ^
    "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%STARTMENU%'); " ^
    "$s.TargetPath = '%APPDIR%\WeatherWidget.exe'; " ^
    "$s.WorkingDirectory = '%APPDIR%'; " ^
    "$s.Description = 'Weather Widget'; " ^
    "$s.Save()"

echo Desktop and Start Menu shortcuts created.
echo.

REM ---------------------------------------------------------------
REM 5. Autostart on Windows login (optional)
REM ---------------------------------------------------------------
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Weather.lnk"
choice /C YN /N /M "Start the widget automatically when Windows starts? (Y/N): "
if errorlevel 2 goto skip_autostart
if errorlevel 1 (
    powershell -NoProfile -Command ^
        "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%STARTUP%'); " ^
        "$s.TargetPath = '%APPDIR%\WeatherWidget.exe'; " ^
        "$s.WorkingDirectory = '%APPDIR%'; " ^
        "$s.Save()"
    echo Autostart enabled.
)
:skip_autostart

echo.
echo ============================================
echo   Setup complete!
echo   A "Weather" shortcut is on your Desktop.
echo ============================================
echo.

choice /C YN /N /M "Launch the widget now? (Y/N): "
if errorlevel 2 goto end
if errorlevel 1 start "" "%APPDIR%\WeatherWidget.exe"

:end
pause
