@echo off
title Weather Widget - Uninstall
color 0C

set "APPDIR=%LOCALAPPDATA%\WeatherWidget"
set "DESKTOP=%USERPROFILE%\Desktop\Weather.lnk"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Weather.lnk"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Weather.lnk"

echo This will remove:
echo   %APPDIR%
echo   Desktop shortcut
echo   Start Menu shortcut
echo   Autostart shortcut (if any)
echo.
choice /C YN /N /M "Continue with uninstall? (Y/N): "
if errorlevel 2 exit /b 0

taskkill /IM WeatherWidget.exe /F >nul 2>&1

if exist "%DESKTOP%" del /q "%DESKTOP%"
if exist "%STARTMENU%" del /q "%STARTMENU%"
if exist "%STARTUP%" del /q "%STARTUP%"
if exist "%APPDIR%" rmdir /s /q "%APPDIR%"

echo.
echo Weather Widget has been removed.
pause
