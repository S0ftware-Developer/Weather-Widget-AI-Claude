@echo off
REM Quick run from source for development, no install needed.
REM Tries pythonw first (no console window), then py -3, then python.

where pythonw >nul 2>&1
if not errorlevel 1 (
    start "" pythonw "%~dp0weather_widget.py"
    goto :eof
)

py -3 --version >nul 2>&1
if not errorlevel 1 (
    start "" py -3 "%~dp0weather_widget.py"
    goto :eof
)

python --version >nul 2>&1
if not errorlevel 1 (
    start "" python "%~dp0weather_widget.py"
    goto :eof
)

echo Python was not found. Install Python 3.10+ from python.org
echo or use install.bat for a full install.
pause
