# -*- coding: utf-8 -*-
"""
Компактный виджет погоды для рабочего стола Windows 10.

Технологии: только стандартная библиотека Python (tkinter, urllib, json).
Дополнительные пакеты устанавливать не нужно.

Источник данных: Open-Meteo (https://open-meteo.com) — бесплатный API,
API-ключ не требуется.

Запуск:
    python weather_widget.py

Настройки (город, единицы измерения, тема, положение окна) сохраняются
в файл widget_config.json рядом со скриптом и восстанавливаются при
следующем запуске.
"""

import json
import os
import sys
import threading
import tkinter as tk
from tkinter import font as tkfont
import urllib.request
import urllib.parse
import urllib.error

# --------------------------------------------------------------------------
# Настройки и константы
# --------------------------------------------------------------------------

def _base_dir():
    """Папка, где лежит .exe (в собранной версии) или .py (при запуске из
    исходников). В режиме PyInstaller --onefile __file__ указывает на
    временную папку распаковки, которая меняется при каждом запуске, —
    поэтому для собранного приложения используем путь к самому exe."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


CONFIG_PATH = os.path.join(_base_dir(), "widget_config.json")

DEFAULT_CONFIG = {
    "city": "Frankfurt",
    "city_display": "Франкфурт",
    "unit": "C",        # "C" или "F"
    "theme": "dark",     # "dark" или "light"
    "topmost": True,
    "pos_x": 80,
    "pos_y": 80,
    "autorefresh_minutes": 20,
}

AUTOREFRESH_MS = 20 * 60 * 1000  # 20 минут

LIGHT = {
    "bg": "#F3F5F8",
    "panel": "#FFFFFF",
    "text": "#1C1F24",
    "sub": "#5B6068",
    "chip": "#EDEFF3",
    "accent": "#F5A623",
    "border": "#DADFE6",
    "btn_hover": "#E4E7EC",
}

DARK = {
    "bg": "#202228",
    "panel": "#26282F",
    "text": "#F2F3F5",
    "sub": "#B7BCC4",
    "chip": "#2B2E36",
    "accent": "#FFC24B",
    "border": "#34363D",
    "btn_hover": "#31333B",
}

# Коды погоды WMO -> (иконка эмодзи, текст на русском)
WMO_ICONS = {
    0: ("\u2600", "Ясно"),
    1: ("\U0001F324", "Малооблачно"),
    2: ("\u26C5", "Переменная облачность"),
    3: ("\u2601", "Облачно"),
    45: ("\U0001F32B", "Туман"),
    48: ("\U0001F32B", "Изморозь"),
    51: ("\U0001F326", "Морось"),
    53: ("\U0001F326", "Морось"),
    55: ("\U0001F327", "Сильная морось"),
    56: ("\U0001F327", "Ледяная морось"),
    57: ("\U0001F327", "Ледяная морось"),
    61: ("\U0001F326", "Небольшой дождь"),
    63: ("\U0001F327", "Дождь"),
    65: ("\U0001F327", "Сильный дождь"),
    66: ("\U0001F327", "Ледяной дождь"),
    67: ("\U0001F327", "Ледяной дождь"),
    71: ("\U0001F328", "Небольшой снег"),
    73: ("\U0001F328", "Снег"),
    75: ("\u2744", "Сильный снег"),
    77: ("\u2744", "Снежные зёрна"),
    80: ("\U0001F326", "Ливень"),
    81: ("\U0001F327", "Ливень"),
    82: ("\u26C8", "Сильный ливень"),
    85: ("\U0001F328", "Снегопад"),
    86: ("\u2744", "Сильный снегопад"),
    95: ("\u26C8", "Гроза"),
    96: ("\u26C8", "Гроза с градом"),
    99: ("\u26C8", "Сильная гроза"),
}


def icon_and_text(code):
    return WMO_ICONS.get(code, ("\u2753", "Нет данных"))


def c_to_f(c):
    return c * 9.0 / 5.0 + 32.0


# --------------------------------------------------------------------------
# Работа с конфигом
# --------------------------------------------------------------------------

def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                saved = json.load(f)
            cfg.update(saved)
        except (OSError, json.JSONDecodeError):
            pass
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# --------------------------------------------------------------------------
# Запросы к Open-Meteo (без внешних зависимостей, только urllib)
# --------------------------------------------------------------------------

class WeatherError(Exception):
    pass


def geocode_city(name):
    """Возвращает {'name', 'country', 'lat', 'lon'} или None, если не найдено."""
    params = {"name": name, "count": 1, "language": "ru", "format": "json"}
    url = "https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError) as e:
        raise WeatherError("Нет соединения с интернетом") from e

    results = data.get("results")
    if not results:
        return None
    r = results[0]
    return {
        "name": r.get("name", name),
        "country": r.get("country", ""),
        "lat": r["latitude"],
        "lon": r["longitude"],
    }


def fetch_weather(lat, lon):
    params = {
        "latitude": lat,
        "longitude": lon,
        "current": "temperature_2m,apparent_temperature,weather_code",
        "hourly": "temperature_2m,weather_code",
        "daily": "temperature_2m_max,temperature_2m_min,weather_code",
        "timezone": "auto",
        "forecast_days": 2,
    }
    url = "https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError) as e:
        raise WeatherError("Не удалось получить данные о погоде") from e


def build_forecast_chips(data):
    """Возвращает список из 4 элементов: (подпись, код_погоды, температура)."""
    chips = []
    hourly_time = data.get("hourly", {}).get("time", [])
    hourly_temp = data.get("hourly", {}).get("temperature_2m", [])
    hourly_code = data.get("hourly", {}).get("weather_code", [])

    # найдём индекс текущего часа
    current_time = data.get("current", {}).get("time")
    start_idx = 0
    if current_time in hourly_time:
        start_idx = hourly_time.index(current_time)

    offsets = [3, 6, 9]
    for off in offsets:
        idx = start_idx + off
        if idx < len(hourly_time):
            label = hourly_time[idx][11:16]  # "HH:MM"
            chips.append((label, hourly_code[idx], hourly_temp[idx]))

    daily_max = data.get("daily", {}).get("temperature_2m_max", [])
    daily_code = data.get("daily", {}).get("weather_code", [])
    if len(daily_max) > 1:
        chips.append(("Завтра", daily_code[1], daily_max[1]))

    while len(chips) < 4:
        chips.append(("--:--", 0, None))

    return chips[:4]


# --------------------------------------------------------------------------
# Виджет
# --------------------------------------------------------------------------

class WeatherWidget(tk.Tk):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.theme = DARK if self.cfg.get("theme") == "dark" else LIGHT
        self.unit = self.cfg.get("unit", "C")

        self.weather_data = None
        self.location_name = self.cfg.get("city_display", self.cfg.get("city"))
        self._drag_offset = (0, 0)
        self._autorefresh_job = None

        self.title("Погода")
        self.overrideredirect(True)          # без стандартной рамки/заголовка Windows
        self.attributes("-topmost", bool(self.cfg.get("topmost", True)))
        self.geometry(f"250x330+{self.cfg.get('pos_x', 80)}+{self.cfg.get('pos_y', 80)}")
        self.configure(bg=self.theme["bg"])

        self._fonts = {
            "city": tkfont.Font(family="Segoe UI Semibold", size=11),
            "temp": tkfont.Font(family="Segoe UI Light", size=30),
            "condition": tkfont.Font(family="Segoe UI", size=10),
            "sub": tkfont.Font(family="Segoe UI", size=8),
            "chip_label": tkfont.Font(family="Segoe UI Semibold", size=7),
            "chip_temp": tkfont.Font(family="Segoe UI Semibold", size=9),
            "icon_big": tkfont.Font(family="Segoe UI Emoji", size=30),
            "icon_small": tkfont.Font(family="Segoe UI Emoji", size=13),
            "icon_btn": tkfont.Font(family="Segoe UI", size=10),
            "footer": tkfont.Font(family="Segoe UI", size=7),
        }

        self._build_ui()
        self.after(150, self.refresh_weather)
        self._schedule_autorefresh()

        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------------------------------------------------------- UI --

    def _build_ui(self):
        t = self.theme
        self.main = tk.Frame(self, bg=t["panel"], bd=0, highlightthickness=1,
                              highlightbackground=t["border"])
        self.main.pack(fill="both", expand=True, padx=1, pady=1)

        # --- заголовок (перетаскивание окна за эту область) ---
        header = tk.Frame(self.main, bg=t["panel"])
        header.pack(fill="x", padx=14, pady=(12, 0))
        header.bind("<Button-1>", self._start_drag)
        header.bind("<B1-Motion>", self._do_drag)

        self.city_label = tk.Label(header, text=self.location_name, font=self._fonts["city"],
                                    bg=t["panel"], fg=t["text"], anchor="w")
        self.city_label.pack(side="left")
        self.city_label.bind("<Button-1>", self._start_drag)
        self.city_label.bind("<B1-Motion>", self._do_drag)

        btns = tk.Frame(header, bg=t["panel"])
        btns.pack(side="right")

        self.close_btn = self._make_icon_button(btns, "\u2715", self.on_close)
        self.close_btn.pack(side="right", padx=(6, 0))
        self.settings_btn = self._make_icon_button(btns, "\u2699", self.open_settings)
        self.settings_btn.pack(side="right", padx=(6, 0))
        self.refresh_btn = self._make_icon_button(btns, "\u27F3", self.refresh_weather)
        self.refresh_btn.pack(side="right", padx=(6, 0))

        # --- главный ряд: иконка + температура ---
        main_row = tk.Frame(self.main, bg=t["panel"])
        main_row.pack(fill="x", padx=14, pady=(4, 0))

        self.icon_label = tk.Label(main_row, text="\u26C5", font=self._fonts["icon_big"],
                                    bg=t["panel"], fg=t["accent"])
        self.icon_label.pack(side="left")

        self.temp_label = tk.Label(main_row, text="--°", font=self._fonts["temp"],
                                    bg=t["panel"], fg=t["text"])
        self.temp_label.pack(side="left", padx=(8, 0))

        self.condition_label = tk.Label(self.main, text="Загрузка...", font=self._fonts["condition"],
                                         bg=t["panel"], fg=t["text"], anchor="w")
        self.condition_label.pack(fill="x", padx=14, pady=(2, 0))

        self.sub_label = tk.Label(self.main, text="", font=self._fonts["sub"],
                                   bg=t["panel"], fg=t["sub"], anchor="w")
        self.sub_label.pack(fill="x", padx=14, pady=(2, 0))

        # --- разделитель ---
        self.divider = tk.Frame(self.main, bg=t["border"], height=1)
        self.divider.pack(fill="x", padx=14, pady=(12, 10))

        # --- прогноз ---
        self.forecast_row = tk.Frame(self.main, bg=t["panel"])
        self.forecast_row.pack(fill="x", padx=10)

        self.chip_widgets = []
        for _ in range(4):
            chip = tk.Frame(self.forecast_row, bg=t["chip"])
            chip.pack(side="left", expand=True, fill="both", padx=3)
            lbl_time = tk.Label(chip, text="--:--", font=self._fonts["chip_label"],
                                 bg=t["chip"], fg=t["sub"])
            lbl_time.pack(pady=(6, 3))
            lbl_icon = tk.Label(chip, text="\u26C5", font=self._fonts["icon_small"],
                                 bg=t["chip"], fg=t["accent"])
            lbl_icon.pack()
            lbl_temp = tk.Label(chip, text="--°", font=self._fonts["chip_temp"],
                                 bg=t["chip"], fg=t["text"])
            lbl_temp.pack(pady=(3, 6))
            self.chip_widgets.append((chip, lbl_time, lbl_icon, lbl_temp))

        # --- футер ---
        self.footer_label = tk.Label(self.main, text="", font=self._fonts["footer"],
                                      bg=t["panel"], fg=t["sub"], anchor="e")
        self.footer_label.pack(fill="x", padx=14, pady=(10, 10))

    def _make_icon_button(self, parent, symbol, command):
        t = self.theme
        btn = tk.Label(parent, text=symbol, font=self._fonts["icon_btn"],
                        bg=t["panel"], fg=t["sub"], cursor="hand2")
        btn.bind("<Button-1>", lambda e: command())
        btn.bind("<Enter>", lambda e: btn.configure(fg=t["text"]))
        btn.bind("<Leave>", lambda e: btn.configure(fg=t["sub"]))
        return btn

    # ------------------------------------------------------------ drag --

    def _start_drag(self, event):
        self._drag_offset = (event.x, event.y)

    def _do_drag(self, event):
        x = self.winfo_x() + event.x - self._drag_offset[0]
        y = self.winfo_y() + event.y - self._drag_offset[1]
        self.geometry(f"+{x}+{y}")

    # --------------------------------------------------------- weather --

    def refresh_weather(self):
        self.refresh_btn.configure(text="\u27F3")
        self.condition_label.configure(text="Обновление...")
        threading.Thread(target=self._fetch_weather_thread, daemon=True).start()

    def _fetch_weather_thread(self):
        try:
            loc = geocode_city(self.cfg.get("city", "Frankfurt"))
            if loc is None:
                self.after(0, lambda: self._show_error("Город не найден"))
                return
            data = fetch_weather(loc["lat"], loc["lon"])
            display_name = loc["name"]
            self.after(0, lambda: self._apply_weather(display_name, data))
        except WeatherError as e:
            self.after(0, lambda: self._show_error(str(e)))
        except Exception as e:  # неожиданная ошибка — не роняем виджет
            self.after(0, lambda: self._show_error("Ошибка: " + str(e)))

    def _apply_weather(self, display_name, data):
        self.weather_data = data
        self.location_name = display_name
        self.cfg["city_display"] = display_name
        self.city_label.configure(text=display_name)

        current = data.get("current", {})
        temp_c = current.get("temperature_2m")
        feels_c = current.get("apparent_temperature")
        code = current.get("weather_code", 0)
        icon, text = icon_and_text(code)

        daily = data.get("daily", {})
        max_c = daily.get("temperature_2m_max", [None])[0]
        min_c = daily.get("temperature_2m_min", [None])[0]

        self.icon_label.configure(text=icon)
        self.temp_label.configure(text=self._format_temp(temp_c))
        self.condition_label.configure(text=text)

        feels_str = self._format_temp(feels_c) if feels_c is not None else "--"
        max_str = self._format_temp(max_c) if max_c is not None else "--"
        min_str = self._format_temp(min_c) if min_c is not None else "--"
        self.sub_label.configure(text=f"Ощущается как {feels_str} \u00b7 Макс {max_str} / Мин {min_str}")

        chips = build_forecast_chips(data)
        for (chip, lbl_time, lbl_icon, lbl_temp), (label, ccode, ctemp) in zip(self.chip_widgets, chips):
            c_icon, _ = icon_and_text(ccode)
            lbl_time.configure(text=label)
            lbl_icon.configure(text=c_icon)
            lbl_temp.configure(text=self._format_temp(ctemp) if ctemp is not None else "--°")

        self.footer_label.configure(text="Обновлено только что")
        save_config(self.cfg)

    def _format_temp(self, celsius):
        if celsius is None:
            return "--°"
        if self.unit == "F":
            return f"{c_to_f(celsius):.0f}\u00b0"
        return f"{celsius:.0f}\u00b0"

    def _show_error(self, message):
        self.condition_label.configure(text=message)
        self.sub_label.configure(text="Проверьте название города и подключение к интернету")
        self.footer_label.configure(text="Ошибка обновления")

    def _schedule_autorefresh(self):
        if self._autorefresh_job is not None:
            self.after_cancel(self._autorefresh_job)
        self._autorefresh_job = self.after(AUTOREFRESH_MS, self._autorefresh_tick)

    def _autorefresh_tick(self):
        self.refresh_weather()
        self._schedule_autorefresh()

    # --------------------------------------------------------- settings --

    def open_settings(self):
        t = self.theme
        win = tk.Toplevel(self)
        win.title("Настройки")
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.configure(bg=t["panel"], highlightthickness=1, highlightbackground=t["border"])
        x = self.winfo_x() + 20
        y = self.winfo_y() + 20
        win.geometry(f"220x260+{x}+{y}")

        pad = {"padx": 14, "pady": (10, 0)}

        header = tk.Frame(win, bg=t["panel"])
        header.pack(fill="x", padx=14, pady=(12, 0))
        tk.Label(header, text="Настройки", font=self._fonts["city"],
                 bg=t["panel"], fg=t["text"]).pack(side="left")
        close = tk.Label(header, text="\u2715", font=self._fonts["icon_btn"],
                          bg=t["panel"], fg=t["sub"], cursor="hand2")
        close.pack(side="right")
        close.bind("<Button-1>", lambda e: win.destroy())

        tk.Label(win, text="Город", font=self._fonts["sub"], bg=t["panel"], fg=t["sub"],
                 anchor="w").pack(fill="x", **pad)
        city_var = tk.StringVar(value=self.cfg.get("city", "Frankfurt"))
        city_entry = tk.Entry(win, textvariable=city_var, font=self._fonts["condition"],
                               bg=t["chip"], fg=t["text"], insertbackground=t["text"],
                               relief="flat")
        city_entry.pack(fill="x", padx=14, pady=(2, 0), ipady=4)

        unit_var = tk.StringVar(value=self.unit)
        unit_frame = tk.Frame(win, bg=t["panel"])
        unit_frame.pack(fill="x", padx=14, pady=(10, 0))
        tk.Radiobutton(unit_frame, text="\u00b0C", variable=unit_var, value="C",
                        bg=t["panel"], fg=t["text"], selectcolor=t["chip"],
                        activebackground=t["panel"], font=self._fonts["sub"]).pack(side="left")
        tk.Radiobutton(unit_frame, text="\u00b0F", variable=unit_var, value="F",
                        bg=t["panel"], fg=t["text"], selectcolor=t["chip"],
                        activebackground=t["panel"], font=self._fonts["sub"]).pack(side="left", padx=(10, 0))

        theme_var = tk.StringVar(value=self.cfg.get("theme", "dark"))
        theme_frame = tk.Frame(win, bg=t["panel"])
        theme_frame.pack(fill="x", padx=14, pady=(10, 0))
        tk.Radiobutton(theme_frame, text="Тёмная", variable=theme_var, value="dark",
                        bg=t["panel"], fg=t["text"], selectcolor=t["chip"],
                        activebackground=t["panel"], font=self._fonts["sub"]).pack(side="left")
        tk.Radiobutton(theme_frame, text="Светлая", variable=theme_var, value="light",
                        bg=t["panel"], fg=t["text"], selectcolor=t["chip"],
                        activebackground=t["panel"], font=self._fonts["sub"]).pack(side="left", padx=(10, 0))

        topmost_var = tk.BooleanVar(value=bool(self.cfg.get("topmost", True)))
        tk.Checkbutton(win, text="Поверх всех окон", variable=topmost_var,
                        bg=t["panel"], fg=t["text"], selectcolor=t["chip"],
                        activebackground=t["panel"], font=self._fonts["sub"]).pack(
            anchor="w", padx=14, pady=(10, 0))

        def save_and_close():
            self.cfg["city"] = city_var.get().strip() or "Frankfurt"
            self.unit = unit_var.get()
            self.cfg["unit"] = self.unit
            new_theme_name = theme_var.get()
            theme_changed = new_theme_name != self.cfg.get("theme")
            self.cfg["theme"] = new_theme_name
            self.cfg["topmost"] = topmost_var.get()
            self.attributes("-topmost", self.cfg["topmost"])
            save_config(self.cfg)
            win.destroy()
            if theme_changed:
                self._apply_theme(DARK if new_theme_name == "dark" else LIGHT)
            self.refresh_weather()

        save_btn = tk.Label(win, text="Сохранить", font=self._fonts["condition"],
                             bg=t["accent"], fg="#1C1F24", cursor="hand2")
        save_btn.pack(fill="x", padx=14, pady=(16, 12), ipady=6)
        save_btn.bind("<Button-1>", lambda e: save_and_close())

    def _apply_theme(self, new_theme):
        """Пересобирает интерфейс с новой темой (просто и надёжно)."""
        self.theme = new_theme
        self.configure(bg=new_theme["bg"])
        self.main.destroy()
        self._build_ui()

    # -------------------------------------------------------------- exit --

    def on_close(self):
        self.cfg["pos_x"] = self.winfo_x()
        self.cfg["pos_y"] = self.winfo_y()
        save_config(self.cfg)
        self.destroy()


def main():
    app = WeatherWidget()
    app.mainloop()


if __name__ == "__main__":
    main()
