@echo off
chcp 65001 >nul
REM Быстрый запуск из исходников для разработки, без установки.
REM Пробует pythonw (без окна консоли), затем py -3, затем python.

where pythonw >nul 2>&1
if not errorlevel 1 (
    start "" pythonw "%~dp0weather_widget.py"
    goto :eof
)

py -3 --version >nul 2>&1
if not errorlevel 1 (
    start "" py -3 "%~dp0weather_widget.py"
    goto :eof
)

python --version >nul 2>&1
if not errorlevel 1 (
    start "" python "%~dp0weather_widget.py"
    goto :eof
)

echo Python не найден. Установите Python 3.10+ с python.org
echo или используйте install.bat для полной установки.
pause
