@echo off
chcp 65001 >nul
title Удаление — Виджет погоды
color 0C

set "APPDIR=%LOCALAPPDATA%\WeatherWidget"
set "DESKTOP=%USERPROFILE%\Desktop\Погода.lnk"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Погода.lnk"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Погода.lnk"

echo Будет удалено:
echo   %APPDIR%
echo   Ярлык на рабочем столе
echo   Ярлык в меню Пуск
echo   Ярлык автозапуска (если есть)
echo.
choice /C YN /N /M "Продолжить удаление? (Y/N): "
if errorlevel 2 exit /b 0

taskkill /IM WeatherWidget.exe /F >nul 2>&1

if exist "%DESKTOP%" del /q "%DESKTOP%"
if exist "%STARTMENU%" del /q "%STARTMENU%"
if exist "%STARTUP%" del /q "%STARTUP%"
if exist "%APPDIR%" rmdir /s /q "%APPDIR%"

echo.
echo Виджет погоды удалён.
pause
