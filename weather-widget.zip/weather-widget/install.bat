@echo off
chcp 65001 >nul
setlocal
title Установка — Виджет погоды
color 0B

echo ============================================
echo   Установка виджета погоды для Windows 10
echo ============================================
echo.

set "APPDIR=%LOCALAPPDATA%\WeatherWidget"
set "SRCDIR=%~dp0"
set "BUILDTMP=%TEMP%\weatherwidget_build"

REM ---------------------------------------------------------------
REM 1. Найти Python (сначала py-launcher, потом python)
REM ---------------------------------------------------------------
set "PYCMD="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3"

if not defined PYCMD (
    python --version >nul 2>&1
    if not errorlevel 1 set "PYCMD=python"
)

if not defined PYCMD (
    echo Python не найден на этом компьютере.
    where winget >nul 2>&1
    if not errorlevel 1 (
        echo Пробую установить Python автоматически через winget...
        winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
        echo.
        echo Установка Python завершена. Пожалуйста, ЗАКРОЙТЕ это окно
        echo и запустите install.bat ещё раз, чтобы продолжить установку виджета.
        pause
        exit /b 0
    ) else (
        echo Автоматическая установка невозможна ^(нет winget^).
        echo Установите Python 3.10+ вручную:
        echo   https://www.python.org/downloads/windows/
        echo При установке обязательно отметьте "Add python.exe to PATH".
        echo Затем запустите install.bat ещё раз.
        pause
        exit /b 1
    )
)

echo Найден Python: %PYCMD%
echo.

REM ---------------------------------------------------------------
REM 2. Установить PyInstaller (тихо, только для сборки — обычному
REM    пользователю программы он не понадобится)
REM ---------------------------------------------------------------
echo Подготовка инструмента сборки...
%PYCMD% -m pip install --quiet --disable-pip-version-check pyinstaller
if errorlevel 1 (
    echo Не удалось установить PyInstaller. Проверьте подключение к интернету.
    pause
    exit /b 1
)

REM ---------------------------------------------------------------
REM 3. Собрать WeatherWidget.exe прямо в папку приложения
REM ---------------------------------------------------------------
echo Сборка приложения...
if not exist "%APPDIR%" mkdir "%APPDIR%"

%PYCMD% -m PyInstaller --onefile --noconsole --clean ^
    --name WeatherWidget ^
    --distpath "%APPDIR%" ^
    --workpath "%BUILDTMP%" ^
    --specpath "%BUILDTMP%" ^
    "%SRCDIR%weather_widget.py"

if not exist "%APPDIR%\WeatherWidget.exe" (
    echo.
    echo Сборка не удалась — файл WeatherWidget.exe не создан.
    pause
    exit /b 1
)

REM Убираем временные файлы сборки
rmdir /s /q "%BUILDTMP%" >nul 2>&1

echo.
echo Приложение собрано: %APPDIR%\WeatherWidget.exe
echo.

REM ---------------------------------------------------------------
REM 4. Ярлыки — Рабочий стол и меню Пуск
REM ---------------------------------------------------------------
echo Создание ярлыков...

set "DESKTOP=%USERPROFILE%\Desktop\Погода.lnk"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Погода.lnk"

powershell -NoProfile -Command ^
    "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%DESKTOP%'); " ^
    "$s.TargetPath = '%APPDIR%\WeatherWidget.exe'; " ^
    "$s.WorkingDirectory = '%APPDIR%'; " ^
    "$s.Description = 'Виджет погоды'; " ^
    "$s.Save()"

powershell -NoProfile -Command ^
    "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%STARTMENU%'); " ^
    "$s.TargetPath = '%APPDIR%\WeatherWidget.exe'; " ^
    "$s.WorkingDirectory = '%APPDIR%'; " ^
    "$s.Description = 'Виджет погоды'; " ^
    "$s.Save()"

echo Ярлык на рабочем столе и в меню Пуск созданы.
echo.

REM ---------------------------------------------------------------
REM 5. Автозапуск при входе в Windows (по желанию)
REM ---------------------------------------------------------------
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Погода.lnk"
choice /C YN /N /M "Запускать виджет автоматически при входе в Windows? (Y/N): "
if errorlevel 2 goto skip_autostart
if errorlevel 1 (
    powershell -NoProfile -Command ^
        "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%STARTUP%'); " ^
        "$s.TargetPath = '%APPDIR%\WeatherWidget.exe'; " ^
        "$s.WorkingDirectory = '%APPDIR%'; " ^
        "$s.Save()"
    echo Автозапуск включён.
)
:skip_autostart

echo.
echo ============================================
echo   Установка завершена!
echo   Ярлык "Погода" — на рабочем столе.
echo ============================================
echo.

choice /C YN /N /M "Запустить виджет сейчас? (Y/N): "
if errorlevel 2 goto end
if errorlevel 1 start "" "%APPDIR%\WeatherWidget.exe"

:end
pause
